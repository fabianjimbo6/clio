@echo off
chcp 65001 >nul
title 1. COPIA DE SEGURIDAD TOTAL - Radio F9211B (Renault Clio 2 - Fabian)
color 0B

echo ============================================================================
echo        1. COPIA DE SEGURIDAD COMPLETA - RADIO ANDROID F9211B
echo ============================================================================
echo.
echo Antes de empezar, asegurate de que tu Laptop y tu Radio esten conectados
echo a la misma red Wi-Fi (por ejemplo, al Hotspot de tu celular) y que hayas
echo activado "Depuracion por Wi-Fi" o "Depuracion USB" en la radio.
echo.
set /p RADIO_IP="Escribe la direccion IP de tu radio (ejemplo 192.168.43.105): "

if "%RADIO_IP%"=="" (
    echo [ERROR] No ingresaste ninguna direccion IP.
    pause
    exit /b 1
)

echo.
echo [1/6] Conectando a la radio en %RADIO_IP%:5555 ...
adb connect %RADIO_IP%:5555
timeout /t 2 >nul

echo.
echo [2/6] Creando carpeta de respaldo en tu PC...
set BACKUP_DIR=Respaldo_Radio_F9211B
if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"
if not exist "%BACKUP_DIR%\APKs_Originales" mkdir "%BACKUP_DIR%\APKs_Originales"

echo.
echo [3/6] Guardando lista completa de aplicaciones y servicios originales...
adb -s %RADIO_IP%:5555 shell pm list packages -f > "%BACKUP_DIR%\lista_completa_paquetes.txt"
adb -s %RADIO_IP%:5555 shell pm list packages -e > "%BACKUP_DIR%\paquetes_activos_originales.txt"
adb -s %RADIO_IP%:5555 shell pm list packages -d > "%BACKUP_DIR%\paquetes_desactivados_originales.txt"
adb -s %RADIO_IP%:5555 shell cmd shortcut get-default-launcher > "%BACKUP_DIR%\launcher_original.txt" 2>nul

echo.
echo [4/6] Guardando propiedades del sistema (build.prop) y ajustes de animacion/zona horaria...
adb -s %RADIO_IP%:5555 shell getprop > "%BACKUP_DIR%\propiedades_sistema_getprop.txt"
adb -s %RADIO_IP%:5555 shell settings list system > "%BACKUP_DIR%\ajustes_system.txt"
adb -s %RADIO_IP%:5555 shell settings list global > "%BACKUP_DIR%\ajustes_global.txt"
adb -s %RADIO_IP%:5555 shell settings list secure > "%BACKUP_DIR%\ajustes_secure.txt"

echo.
echo [5/6] Extrayendo copia de los APKs del Launcher, Radio y Bluetooth originales...
for /f "tokens=2 delims==" %%P in ('adb -s %RADIO_IP%:5555 shell pm list packages ^| findstr /i "launcher radio bt bluetooth music xyauto autochips"') do (
    for /f "tokens=2 delims=:" %%A in ('adb -s %RADIO_IP%:5555 shell pm path %%P') do (
        echo Respaldando %%P ...
        adb -s %RADIO_IP%:5555 pull "%%A" "%BACKUP_DIR%\APKs_Originales\%%P.apk" >nul 2>&1
    )
)

echo.
echo [6/6] Generando archivo automatico de restauracion de paquetes...
echo @echo off > "%BACKUP_DIR%\restaurar_paquetes_exactos.bat"
for /f "tokens=2 delims=:" %%P in (%BACKUP_DIR%\paquetes_activos_originales.txt) do (
    echo adb -s %%1 shell pm enable %%P >> "%BACKUP_DIR%\restaurar_paquetes_exactos.bat"
)

echo.
echo ============================================================================
echo [LISTO] Tu copia de seguridad se guardo en la carpeta: %BACKUP_DIR%
echo Ya puedes ejecutar con total tranquilidad el paso 2 (Optimizar e Instalar).
echo ============================================================================
pause
