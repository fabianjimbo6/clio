@echo off
chcp 65001 >nul
title 3. RESTAURAR RADIO A SU ESTADO ORIGINAL - F9211B
color 0E

echo ============================================================================
echo        3. RESTAURACION COMPLETA AL ESTADO ORIGINAL DE FABRICA
echo ============================================================================
echo.
echo Este script revertira los cambios hechos en el paso 2, reactivara todas
echo las aplicaciones originales desde tu copia de seguridad y quitara el
echo launcher personalizado si deseas volver exactamente a como estaba antes.
echo.
set /p RADIO_IP="Escribe la direccion IP de tu radio (ejemplo 192.168.43.105): "

if "%RADIO_IP%"=="" (
    echo [ERROR] No ingresaste ninguna direccion IP.
    pause
    exit /b 1
)

echo.
echo [1/4] Conectando a %RADIO_IP%:5555 ...
adb connect %RADIO_IP%:5555
timeout /t 2 >nul

echo.
echo [2/4] Restaurando velocidad de animaciones original (1.0x)...
adb -s %RADIO_IP%:5555 shell settings put global window_animation_scale 1.0
adb -s %RADIO_IP%:5555 shell settings put global transition_animation_scale 1.0
adb -s %RADIO_IP%:5555 shell settings put global animator_duration_scale 1.0

echo.
echo [3/4] Reactivando todos los paquetes originales desde tu respaldo...
if exist "Respaldo_Radio_F9211B\restaurar_paquetes_exactos.bat" (
    call "Respaldo_Radio_F9211B\restaurar_paquetes_exactos.bat" %RADIO_IP%:5555
) else (
    for %%B in (
        com.nwd.production.test
        com.nwd.whole.machine
        com.nwd.traversalfile
        com.example.memtester
        com.nwd.autotestor
        com.nwd.carstore.service
        com.nwd.carad.service
        com.nwd.weiweiclient
        com.txznet.txz
        com.txznet.smartadapter
        com.txznet.aipal
        com.autonavi.amapauto
        com.autonavi.amapautolite
        com.baidu.BaiduMap
        com.baidu.navi
        com.sdu.didi.psnger
        com.antutu.benchmark.full
        com.antutu.ABenchMark
        cm.aptoide.pt
        com.huawei.hicar.demoapp
    ) do (
        adb -s %RADIO_IP%:5555 shell pm enable %%B >nul 2>&1
    )
)

echo.
set /p UNINSTALL="¿Deseas desinstalar tambien CleanLauncher y volver al launcher original? (S/N): "
if /i "%UNINSTALL%"=="S" (
    echo [4/4] Desinstalando CleanLauncher y volviendo al Launcher de fabrica...
    adb -s %RADIO_IP%:5555 uninstall com.simple.carlauncher
) else (
    echo [4/4] CleanLauncher se mantuvo instalado.
)

echo.
echo ============================================================================
echo [LISTO] Tu radio F9211B ha vuelto a su configuracion original sin perder nada.
echo ============================================================================
pause
