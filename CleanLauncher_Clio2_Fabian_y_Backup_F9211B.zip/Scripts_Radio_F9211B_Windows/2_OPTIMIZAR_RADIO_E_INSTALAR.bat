@echo off
chcp 65001 >nul
title 2. OPTIMIZAR RADIO F9211B E INSTALAR CLEANLAUNCHER - Renault Clio 2
color 0A

echo ============================================================================
echo     2. OPTIMIZACION SEGURA Y LAUNCHER CLIO 2 (RADIO ANDROID F9211B)
echo ============================================================================
echo.
set /p RADIO_IP="Escribe la direccion IP de tu radio (ejemplo 192.168.43.105): "

if "%RADIO_IP%"=="" (
    echo [ERROR] No ingresaste ninguna direccion IP.
    pause
    exit /b 1
)

echo.
echo [1/5] Conectando a %RADIO_IP%:5555 ...
adb connect %RADIO_IP%:5555
timeout /t 2 >nul

echo.
echo [2/5] Corrigiendo Zona Horaria ( de China GMT+8 a Ecuador GMT-5 )...
adb -s %RADIO_IP%:5555 shell service call alarm 3 s16 "America/Guayaquil" >nul 2>&1
adb -s %RADIO_IP%:5555 shell setprop persist.sys.timezone "America/Guayaquil" >nul 2>&1
adb -s %RADIO_IP%:5555 shell settings put global auto_time 1 >nul 2>&1
adb -s %RADIO_IP%:5555 shell settings put global auto_time_zone 1 >nul 2>&1

echo.
echo [3/5] Acelerando interfaz (Animaciones a 0.5x para liberar CPU y GPU)...
adb -s %RADIO_IP%:5555 shell settings put global window_animation_scale 0.5
adb -s %RADIO_IP%:5555 shell settings put global transition_animation_scale 0.5
adb -s %RADIO_IP%:5555 shell settings put global animator_duration_scale 0.5

echo.
echo [4/5] Deshabilitando bloatware chino y apps de prueba (Modo Seguro: NO se borran)...
echo (Los servicios de pantalla retractil, MCU, Radio FM, Bluetooth y Volante NO se tocan)
for %%B in (
    com.nwd.production.test
    com.nwd.whole.machine
    com.nwd.traversalfile
    com.example.memtester
    com.nwd.autotestor
    com.nwd.carstore.service
    com.nwd.carad.service
    com.nwd.weiweiclient
    com.txznet.txz
    com.txznet.smartadapter
    com.txznet.aipal
    com.autonavi.amapauto
    com.autonavi.amapautolite
    com.baidu.BaiduMap
    com.baidu.navi
    com.sdu.didi.psnger
    com.antutu.benchmark.full
    com.antutu.ABenchMark
    cm.aptoide.pt
    com.huawei.hicar.demoapp
) do (
    adb -s %RADIO_IP%:5555 shell pm disable-user --user 0 %%B >nul 2>&1
)

echo.
echo [5/5] Verificando e instalando CleanLauncher.apk (si ya esta en esta carpeta)...
if exist "CleanLauncher.apk" (
    echo Instalando CleanLauncher.apk en la radio...
    adb -s %RADIO_IP%:5555 install -r "CleanLauncher.apk"
    echo Otorgando permisos de notificaciones musicales y ubicacion...
    adb -s %RADIO_IP%:5555 shell pm grant com.simple.carlauncher android.permission.ACCESS_FINE_LOCATION >nul 2>&1
    adb -s %RADIO_IP%:5555 shell cmd notification allow_listener com.simple.carlauncher/com.simple.carlauncher.MediaListener >nul 2>&1
    adb -s %RADIO_IP%:5555 shell appops set com.simple.carlauncher SYSTEM_ALERT_WINDOW allow >nul 2>&1
    echo.
    echo [EXITO] CleanLauncher instalado! Presiona el boton "Casita (Home)" en tu radio
    echo y selecciona "Inicio (Siempre)".
) else (
    echo [AVISO] Aun no has copiado "CleanLauncher.apk" dentro de esta carpeta.
    echo La optimizacion de velocidad y zona horaria ya quedo aplicada.
    echo Cuando tengas el archivo "CleanLauncher.apk", ponlo en esta misma carpeta
    echo y vuelve a abrir este script para instalarlo automaticamente.
)

echo.
echo ============================================================================
echo               PROCESO DE OPTIMIZACION COMPLETADO
echo ============================================================================
pause
